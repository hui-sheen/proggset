#!/usr/bin/perl -w

use strict;

die "Please provide gene list file (and PPI network file). If the PPI network file is not supplied, the PPI network generated from the incorporation of PPI data from HPRD and KEGG will be used.\n " if (@ARGV < 1);

my $firstInputFile = $ARGV[0]; #gene list file provided by user
my $secondInputFile; # the PPI network file
$secondInputFile = $ARGV[1] ;
#if (@ARGV > 1){ # the PPI network file is provided by user
#	$secondInputFile = $ARGV[1] ;
#}else{# using the default setting
#	$secondInputFile = "/home/wangxu/galaxy-dist/tools/cspn/reference/PPI_network/#incorporated_PPI_network.txt";
#}
my $firstOutputFile = $ARGV[2];
my $secondOutputFile = $ARGV[3];

my %genes_u; #gene list provided by user
open FI1, "<$firstInputFile"
 or die "Can not open gene list file: $firstInputFile\n";

while(my $line1 = <FI1>){# obtaining the genes from the file
        if($line1 =~ /^(\d+?)\s+/){
                $genes_u{$1} = 1;
        }
}

close FI1;



my $name_pn;
if($secondInputFile =~ /(.+)?\/([^\/]+)\.txt$/){
	$name_pn = $2; 
}elsif($secondInputFile =~ /(.+)?\\([^\\]+)\.txt$/){
	$name_pn = $2 ;
}

#print "$name_pn\n";

#mkdir "/home/wangxu/galaxy-dist/tools/cspn/temp";
#mkdir "/home/wangxu/galaxy-dist/tools/cspn/temp/PPI_or";
#mkdir "/home/wangxu/galaxy-dist/tools/cspn/temp/PPI_and";


open FI2, "<$secondInputFile"
        or die "can not open PPI network file: $secondInputFile\n";

open (FO1, ">", $firstOutputFile) || die("Could not open file $firstOutputFile \n");

#open FO1, ">/home/wangxu/galaxy-dist/tools/cspn/temp/PPI_or/active_PPIs_or_on_".$name_pn.".txt"
#        or die "can not open \"or\" active PPI file";

open (FO2, ">", $secondOutputFile) || die("Could not open file $secondOutputFile \n");

#open FO2, ">/home/wangxu/galaxy-dist/tools/cspn/temp/PPI_and/active_PPIs_and_on_".$name_pn.".txt"
#        or die "can not open \"and\"active PPI file";

while(my $line2 = <FI2>){
        if($line2 =~ /^(\d+?)\s+(\d+?)\s+/){
                
                #By switching the logic operator between '&&' and '||', PPIs of which both genes are in gene list or only one is in list are obtained
                if((exists $genes_u{$1}) || (exists $genes_u{$2})){#only one corresponding gene of this PPI is in the gene list 
                        print FO1 $line2;
                }
                if((exists $genes_u{$1}) && (exists $genes_u{$2})){#both corresponding gene of this PPI are in the gene list 
                        print FO2 $line2;
                }
        }
}

close FO1;
close FO2;
close FI2;
