SYSTEM REQUIREMENT:
1. Linux/Unix OS, Windows OS
2. > 1G memory
3. > 1G disk space
-------------------------------------------------------
INPUT FILES:

1. differentially expressed gene list (only when use get_active_ppi.pl to infer active PPIs)
	e.g. gse6883_BC_PE13TG_u133a&b_diff_gene_signal.txt
	format: gene_Entrez_Id	... [just require the first column should be entrez ids of genes]
OR
 active PPIs file (only when directly exploit cspn.pl to construct Pathway Interaction Network)
	e.g. ./temp/PPI_or/active_PPIs_or_on_incorporated_PPI_network.txt
	format: gene1_Entrez_ID	gene2_Entrez_ID	(attribute...)[just require the first and second column shoudl be entrez ids of the pair of genes related to specific PPI]
[NOTE: active PPIs file could be inferred from differentially expressed gene list by the script: get_active_ppi.pl]

2. PPI network (only when use get_active_ppi.pl to infer active PPIs)
	e.g. ./reference/PPI_network/incorporated_PPI_network.txt
	format: gene1_Entrez_ID	gene2_Entrez_ID	(attribute...)[just require the first and second column shoudl be entrez ids of the pair of genes related to specific PPI]

3. concerned pathway list
  e.g. ./reference/concerned_pathway_list/human_significant_categ_path.txt
  format: pathway_id	pathway_name
 
4. original gene sets 
	e.g. ./reference/original_gene_sets/[file folder]
	format:
		file name: genes_(pathway_id) 
		file content: gene_Entrez_ID	pathway_name	pathway_id
-------------------------------------------------------
STEPS:
1. (optional) infer active PPIs from differentially expressed genes list

	examples
	
	cmd> perl get_active_ppi.pl gse6883_BC_PE13TG_u133a&b_diff_gene_signal.txt
	[get the active PPIs, which are inferred from differentially genes in the provided file based on the default PPI network file ./reference/PPI_network/incorporated_PPI_network.txt]

	cmd> perl get_active_ppi.pl gse6883_BC_PE13TG_u133a&b_diff_gene_signal.txt ./reference/PPI_network/HPRD_PPI_network.txt]
	[get the active PPIs, which are inferred from differentially genes in the provided file based on the specified PPI network file ./reference/PPI_network/HPRD_PPI_network.txt]
	
	temporary output files: the corresponding active PPIs files in "./temp/PPI_or" and "./temp/PPI_and" directories.

2. construct Pathway Interaction Network, obtaine the PPIs deciding pathway interactions in the mean time
	
	examples
	
	cmd> perl cspn.pl ./temp/PPI_or/active_PPIs_or_on_incorporated_PPI_network.txt
	[construct the Pathway Interaction  Network based concerned pathways specified by the default list: ./reference/concerned_pathway_list/human_significant_categ_path.txt]
	
	cmd> perl cspn.pl ./temp/PPI_or/active_PPIs_or_on_incorporated_PPI_network.txt ./reference/concerned_pathway_list/test.txt
	[construct the Pathway Interaction  Network based concerned pathways specified by the given list: ./reference/concerned_pathway_list/test.txt]
	----
	2a. 
	preprocess active PPIs to obtain some temporary files in the directory: ./temp/preprocessed_file/
		
		genes_related_to_active_PPIs.txt (all genes related to active PPIs)
		format: gene_Entrez_ID
		
		sublist_cPathways_2_aPPIs.txt (sublist of concerned pathways having genes related to active PPIs)
		format: pathway_id	the_number_of_genes_which_have_active_PPI_and_appear_in_pathway	the_number_of_genes_in_pathway	pathway_name
		
		genes_of_aPPIs_2_cPathways.txt (genes which are related to active PPIs and appear in concerned pathways at least once)
		format: gene_Entrez_ID
		
		genes_of_each_cPathway_2_aPPIs.txt (genes which are related to active PPIs in each concerned pathway)
		format: gene_Entrez_ID	pathway_id	pathway_name
		
	----
	2b.
	do 1000 permutations. After each permuation, the randomly generated gene sets corresponding to pathways are saved in the file named after the sequence number of the permutation
	temporary files of permutated gene sets are in the directory: ./temp/1000_permutations
	
		aPPIs_related_gene_sets_in_current_case_[sequence #].txt
		examples: aPPIs_related_gene_sets_in_current_case_0.txt [the original case]
							aPPIs_related_gene_sets_in_current_case_1.txt [the randomly generated gene sets of 1st permutation]
		......
	
		format: gene_Entrez_ID	pathway_id	pathway_name
	
	----
	2c.
	compare the number of active PPIs between each pair of corresponding gene sets of pathways in original case with that in each permutation to construct a Pathway Interaction Network.
	
	one of the final output files: ./result/pathway_interaction_network.txt
	format: pathway1_name	pathway2_name	p_value
	
	----
	2d.
	check that which pairs of concerned pathway are involved in each related acitve PPIs
	
	the other one of the final output files: ./result/aPPIs_2_pathway_pairs.txt
	format: gene1_Entrez_ID gene2_Entrez_ID pathway_pairs_list
	
-------------------------------------------------------
OUTPUT FILES:

1. Pathway Interaction Network
	e.g. ./result/pathway_interaction_network.txt
	format: pathway1_name	pathway2_name	p_value

2. Pathway Pairs involved in each related active PPI
	e.g. ./result/aPPIs_2_pathway_pairs.txt
	format: gene1_Entrez_ID gene2_Entrez_ID pathway_pairs_list

-----------------END-------------------------END----------------------



******************************************************************************
******** Following is for extended applications. ****************
******************************************************************************

How to update PPI network or specify new PPI network?
Just put new PPI network file in the directory: ./reference/PPI_network. When use get_active_ppi.pl, specifiy the network file as the second argument.

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

How to provide new concerned pathway listor GO term list?
Just put the file of new concerned pathway list or GO term list in the directory: ./reference/concerned_pathway_list. When use cspn.pl, specifiy the concerned pathway list file as the second argument.
The files should accord with the format:pathway_id/GO_term_id	 pathway_name/GO_term_name
[the pathway_id should be "hsa...", the GO_term_id should be "GO:..."]

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

How to provide new files of gene sets corresponding to pathways or GO terms?
Just put the new files of gene sets corresponding to pathways or GO terms in the directory��./reference/original gene sets/.
The files should accord with the format: gene_Entrez_ID	pathway_name/GO_term_name	pathway_id/GO_term_id
[the pathway_id should be "hsa...", the GO_term_id should be "GO:..."]

$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$