#!/usr/bin/perl -w

#This script is designed to construct Pathway Interaction Network, and to obtaine the PPIs deciding pathway interactions in the mean time

######################################################################
#Firstly, preprocessing the input active PPIs to obtaine related files
#��һ����Ԥ������Ծ�����ʣ��������໥���ù�ϵ���õ�����ļ�

if (@ARGV < 1){
	die "Please specify the active PPI file (and the concerned pathway list file).\n " ;
}
my $infile_aPPIs = $ARGV[0]; #the active PPIs, mandatory argument
my $infile_cPathways=$ARGV[1];;# the concerned pathways, optional argument

#if (@ARGV > 1){ # the concerned pathway list is provided by user
#	$infile_cPathways = $ARGV[1] ;
#}else{# using the default setting
#	$infile_cPathways = "./reference/concerned_pathway_list/#human_significant_categ_path.txt";
#}

my $firstOutputFile = $ARGV[2];
my $secondOutputFile = $ARGV[3];

open FI1, "$infile_aPPIs"
	or die "Can not open file: infile_aPPIs\n";

#mkdir "./temp/preprocessed_file";
open FO1, ">/root/galaxy-dist/tools/cspn/temp/preprocessed_file/genes_related_to_active_PPIs.txt"#all genes related to active PPIs
or die "Can not open file: ./temp/preprocessed_file/genes_related_to_active_PPIs.txt";

my %all_genes_of_aPPIs;
my %aPPIs;
while(my $line1 = <FI1>){
	#getting all genes related to active PPIs
	if($line1 =~ /^(\d+?)\s+(\d+?)\s+/){
		my $gene1 = $1;
		my $gene2 = $2;
		
		if (!exists $all_genes_of_aPPIs{$gene1}){
			$all_genes_of_aPPIs{$gene1} = 1;
			print FO1 "$gene1\n";
		}
		
		if (!exists $all_genes_of_aPPIs{$gene2}){
			$all_genes_of_aPPIs{$gene2} = 1;
			print FO1 "$gene2\n";
		}
		
		if(!exists $aPPIs{$gene1.":".$gene2} && !exists $aPPIs{$gene2.":".$gene1}){
			$aPPIs{$gene1.":".$gene2} = 1;
		}
	}
}
close FI1;
close FO1;

#print "The number of genes related to  active PPIs:\n ".(keys %all_genes_of_aPPIs)."\n";

#reading the concerned pathways
open FI2, "$infile_cPathways"
	or die "Can not open concerned pathway list file: $infile_cPathways";

my %pathway_id2name;
while(my $line2 = <FI2>){
	if($line2 =~ /^(\D+\d+?)\s+?(.+)$/){
		$pathway_id2name{$1} = $2;
	}
}
close FI2;

open FO2, ">/root/galaxy-dist/tools/cspn/temp/preprocessed_file/sublist_cPathways_2_aPPIs.txt"#sublist of concerned pathways having genes related to active PPIs
	or die "Can not open file: ./temp/preprocessed_file/sublist_cPathways_2_aPPIs.txt";
open FO3, ">/root/galaxy-dist/tools/cspn/temp/preprocessed_file/genes_of_aPPIs_2_cPathways.txt"#genes which are related to active PPIs and appear in concerned pathways at least once
	or die "Can not open file: ./temp/preprocessed_file/genes_of_aPPIs_2_cPathways.txt";
open FO4, ">/root/galaxy-dist/tools/cspn/temp/preprocessed_file/genes_of_each_cPathway_2_aPPIs.txt"#genes which are related to active PPIs in each concerned pathway 
	or die "Can not open file: ./temp/preprocessed_filegenes_of_each_cPathway_2_aPPIs.txt";

my $pathway_id;
my %cPathways_2_genes; #pathways in which each gene has ever appeared 
my %genes_2_cPathways; #genes corresponding to each concerned pathway
my %genes_2_aPPIs_and_cPathways; #genes which are related to active PPIs and appear in concerned pathways at least once
my %cPathways_2_aPPIs;#concerned pathways having genes related to active PPIs
my $counter_1; #counting the number of genes in each concerned pathway
my $counter_2; #counting the number of genes related to active PPIs in each concerned pathway
my $counter_total = 0; #counting the total appearance times of genes related to active PPIs in all concerned pathways

foreach $pathway_id(sort keys %pathway_id2name){
	$counter_1 = 0;
	$counter_2 = 0;
	#Original gene sets corresponding to pathways
	#����pathways��ԭʼ����
	open FI3, "/root/galaxy-dist/tools/cspn/reference/original_gene_sets/genes_".$pathway_id.".txt"
		or die "Can not open file ./reference/original_gene_sets/genes_".$pathway_id.".txt";

	while(my $line3 = <FI3>){
		if($line3 =~ /^(\d+?)\s+/){
			my $gene = $1;
			push @{$genes_2_cPathways{$pathway_id}},  $gene;# genes corresponding to concerned pathway the id of which is $pathway_id, each element of the hash is an array
			push @{$cPathways_2_genes{$gene}},  $pathway_id;# pathways in which the $gene has ever appeared , each element of the hash is an array
			$counter_1 ++;
			if (exists $all_genes_of_aPPIs{$gene}){
				print FO4 $gene."\t".$pathway_id."\t".$pathway_id2name{$pathway_id}."\n" ;
				if(!exists $genes_2_aPPIs_and_cPathways{$gene}){
					$genes_2_aPPIs_and_cPathways{$gene} = 1;
					print FO3 $gene."\n";
				}	
				$cPathways_2_aPPIs{$pathway_id} = 1;
				$counter_2 ++;
			}
		}	
	}
	
	close FI3;
	
	if(exists $cPathways_2_aPPIs{$pathway_id}){
			print FO2 "$pathway_id\t$counter_2\t$counter_1\t".$counter_2/$counter_1."\t$pathway_id2name{$pathway_id}\n";
		}
		$counter_total += $counter_2;
}

close FO2;
close FO3;
close FO4;

#print "The number of concerned pathways related to active PPIs: \n ".(keys %cPathways_2_aPPIs)."\n";
#print "The number of genes related to active PPIs appeared in all concerned pathways:\n ".(keys %genes_2_aPPIs_and_cPathways)."\n";
#print "The total times of genes related to active PPIs appeared in all concerned pathways:\n $counter_total\n\n";



###########################################################
#Secondly, doing 1000 Permutations. Each time, a new set of corresponding gene sets of concerned pathways will be obtained
#�ڶ��������ź��������1000���µļ���(����һ�������ĵ�pathway��Ӧ��gene set)Ⱥ�����ϵļ��ϣ�

#my $Timer1=localtime time;
#print "Beginning time of all 1000 permutations:\n$Timer1\n\n";

my $num=0;
my @pathway_id_tmp = sort keys %pathway_id2name;
while($num<=1000){
	#print "Permutation $num\n";
	
	my %genes_2_cPathways_permutation_tmp = %genes_2_cPathways;
  my %genes_2_aPPIs_and_cPathways_permutation_tmp;
        
  if ($num != 0){# When $num = 0, it is the original case.
  	my $counter = 0;
  	my $p1;
    my $p2;
    my $q1;
    my $q2;
    while($counter < 100000){
    	#��100000�ν����õ�������ɵ��µļ���Ⱥ��pathway�ļ��ϣ�
    	$p1 = int(rand(@pathway_id_tmp));
      $p2 = int(rand(@pathway_id_tmp));        	            
      while($p1==$p2){
      	$p2=int(rand(@pathway_id_tmp));
      }
      
      if(exists $genes_2_cPathways{$pathway_id_tmp[$p1]} && exists $genes_2_cPathways{$pathway_id_tmp[$p2]}){
      	$q1 = int(rand(@{$genes_2_cPathways{$pathway_id_tmp[$p1]}}));
        $q2 = int(rand(@{$genes_2_cPathways{$pathway_id_tmp[$p2]}}));
        if ($genes_2_cPathways{$pathway_id_tmp[$p2]}[$q2] == $genes_2_cPathways{$pathway_id_tmp[$p1]}[$q1]){
        	redo;
        }
        
        #Exchange a pair of elements (genes) according to different elements sets (gene sets related to pathways)
        #�������Բ�ͬ���ϣ���Ӧ��pathways��genes���ϣ���һ��Ԫ�أ�gene��
        ($genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$q1], $genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p2]}[$q2]) = ($genes_2_cPathways{$pathway_id_tmp[$p2]}[$q2], $genes_2_cPathways{$pathway_id_tmp[$p1]}[$q1]);
        $counter++;
      }else{
      	$counter++;
      	next;
      	}
      }
      
      my $counter_inner;
      my $counter_outter;
      
      for($p1 = 0; $p1 < @pathway_id_tmp; $p1++){
      	#�ų����ϣ�����pathway���ڲ��غ�Ԫ�أ�gene��
				if(@{$genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}} != 0){
	 Current_Pathway:	for($counter_outter = 0; $counter_outter < @{$genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}}; $counter_outter++){
                			for($counter_inner = $counter_outter + 1; $counter_inner < @{$genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}}; $counter_inner++){
                				if($genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$counter_inner] && $genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$counter_outter] && $genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$counter_inner] == $genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$counter_outter]){

                       		$p2 = int(rand(@pathway_id_tmp));
                        	while($p1 == $p2 || @{$genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p2]}} == 0){
                                $p2=int(rand(@pathway_id_tmp));
                        	}
                					$q1 = $counter_inner;
                					$q2 = int(rand(@{$genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p2]}}));
                					($genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$q1], $genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p2]}[$q2]) = ($genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p2]}[$q2], $genes_2_cPathways_permutation_tmp{$pathway_id_tmp[$p1]}[$q1]);
                					$p1 > $p2 ? ($p1=$p2-1) : ($p1=$p1-1);
                					last Current_Pathway;
                				}
                			}
                		}
           }
        }
 	}

        
  #mkdir "./temp/1000_permutations";
      	
	open FO5, ">/root/galaxy-dist/tools/cspn/temp/1000_permutations/aPPIs_related_gene_sets_in_current_case_$num.txt"
		or die "Can not open file ./temp/1000_permutations/aPPIs_related_gene_sets_in_current_case_$num.txt";
  #���������ɵļ���Ⱥ����Ϣ��ÿ������ֻ�����active PPIs��ص�Ԫ��
  
  foreach $pathway_id(@pathway_id_tmp){
  	my $flag = 0;
  	my $gene;
  	if(@{$genes_2_cPathways_permutation_tmp{$pathway_id}} != 0){
  		foreach $gene(@{$genes_2_cPathways_permutation_tmp{$pathway_id}}){
  			if (exists $all_genes_of_aPPIs{$gene}){			
  					print FO5 $gene."\t".$pathway_id."\t".$pathway_id2name{$pathway_id}."\n";
  					$genes_2_aPPIs_and_cPathways_permutation_tmp{$gene} = 1; 
  			}
  		}
  	}
 
 }
 close FO5;
 #$Timer1 = localtime time;
 #print "Ending time of permutation $num:\n$Timer1\n\n";
 $num++;
}

#$Timer1 = localtime time;
#print "Ending time of all 1000 permutations:\n$Timer1\n";

###########################################################
#Thirdly, comparing the number of active PPIs between each pair of corresponding gene sets of pathways in original case with that in each permutation to construct a Pathway Interaction Network.
#������������ԭʼ������Լ�ÿ�����ź�ÿ��pathways��Ӧ��gene sets֮���active PPIs����Ŀ��
#$Timer1 = localtime time;
#print "Beginning time of counting the number of active PPIs:\n$Timer1\n";

$num = 0;
my %pathway_outter_interactions_number;
my $pathway_pair;
my @outter_interactions_number;

while ($num<=1000){
  my $now=localtime time;
  #print "The $num loop\n$now\n";
  
  my $flag_1 = 0;
  my $pathway_id_1;
  my $pathway_id_2;
  my @genes_of_pathway_1;
  my @genes_of_pathway_2;
  my $gene_1;
  my $gene_2;
  my $flag_2 = 0;
  my $flag = 0;
  
  foreach $pathway_id_1(@pathway_id_tmp){
  	@genes_of_pathway_1 = ();
    $flag_1 = 0;
    open FI3, "/root/galaxy-dist/tools/cspn/temp/1000_permutations/aPPIs_related_gene_sets_in_current_case_$num.txt"
    	or die "Can not open file ./temp/1000_permutations/aPPIs_related_gene_sets_in_current_case_$num.txt";
    while(my $line3 = <FI3>){
    	
      if ($line3 =~ /^(\d+?)\s+(\D+?\d+?)\s+(\w.+)$/i && $2 eq $pathway_id_1){
      	$flag_1 = 1;
      	push (@genes_of_pathway_1,$1);
      }elsif($flag_1 == 1 && $2 ne $pathway_id_1){
      	last;
      }
     }
     close FI3;
     
     foreach $pathway_id_2(@pathway_id_tmp){
     	if($pathway_id_2 ne $pathway_id_1){
     		@genes_of_pathway_2 = ();
     		$flag_2 = 0;
     		
     		open FI4, "/root/galaxy-dist/tools/cspn/temp/1000_permutations/aPPIs_related_gene_sets_in_current_case_$num.txt"
     			or die "Can not open file /root/galaxy-dist/tools/cspn/temp/1000_permutations/aPPIs_related_gene_sets_in_current_case_$num.txt";
     		
     		while(my $line4 = <FI4>){  			
     			if ($line4 =~ /^(\d+?)\s+(\D+?\d+?)\s+(\w.+)\s+/i && $2 eq $pathway_id_2){
     				$flag_2 = 1;
     				push (@genes_of_pathway_2,$1);
     			}elsif($flag_2 == 1 && $2 ne $pathway_id_2){
     				last;
     			}
     		}
     		close FI4;
     		
     		foreach $gene_1(@genes_of_pathway_1){
     			foreach $gene_2 (@genes_of_pathway_2){
     				if ($gene_1 eq $gene_2){
     					next;
     				}
     				if (exists $aPPIs{$gene_1.":".$gene_2} || exists $aPPIs{$gene_2.":".$gene_1}){
     					if (exists $pathway_outter_interactions_number{$pathway_id_2.":".$pathway_id_1}[0]){
     						$pathway_outter_interactions_number{$pathway_id_2.":".$pathway_id_1}[$num]++;    				
     					}else{
     						$pathway_outter_interactions_number{$pathway_id_1.":".$pathway_id_2}[$num]++;
     					}
     				}
     			}
     		}
     	}
     }
   }
  $num++;
 	#$now=localtime time;
  #print "$now\n";
}

#mkdir ("./result/");
open (FO9, ">", $firstOutputFile) || die("Could not open file $firstOutputFile \n");
#open FO9, ">./result/pathway_interaction_network.txt"
#	or die "Can not open file pathway_interaction_network.txt";

foreach $pathway_pair ( sort keys %pathway_outter_interactions_number){
	my $num_3 = 1;
  my $freq_3 = 0;
  my @pathway_id = split /\:/, $pathway_pair;
 
  while ($num_3 <= 1000){	
  	if ($pathway_outter_interactions_number{$pathway_pair}[$num_3] && $pathway_outter_interactions_number{$pathway_pair}[0] && ($pathway_outter_interactions_number{$pathway_pair}[$num_3] >= $pathway_outter_interactions_number{$pathway_pair}[0])){
  		$freq_3++;
    }
    $num_3++;
  }
  print (FO9 "$pathway_id2name{$pathway_id[0]}\t$pathway_id2name{$pathway_id[1]}\t".($freq_3/1000)."\n") if($pathway_outter_interactions_number{$pathway_pair}[0]);
}
close FO9;

#my $Timer2=localtime time;
#print "Ending time of counting the number of active PPIs:\n$Timer2\n";

###########################################################
#Fourthly, checking that which pairs of concerned pathway are involved in each related acitve PPIs
#���Ĳ����鿴ÿһ����ػ�ԾPPI�漰��Щconcerned pathway�ԡ�

#open FO10, ">./result/aPPIs_2_pathway_pairs.txt"
#	or die "Can not open file aPPIs_2_pathway_pairs.txt";
open (FO10, ">", $secondOutputFile) || die("Could not open file $secondOutputFile \n");
my $gene_pair;
foreach $gene_pair (sort keys %aPPIs){
	my @gene = split /:/, $gene_pair;
	my $pathway_pair = '';
	my $pathway_1;
	my $pathway_2;
	foreach $pathway_1 (@{$cPathways_2_genes{$gene[0]}}){
		foreach $pathway_2 (@{$cPathways_2_genes{$gene[1]}}){
			$pathway_pair .= "$pathway_1, $pathway_2;"
		}
	}
	print FO10 $gene[0]."\t".$gene[1]."\t$pathway_pair\n" if $pathway_pair ne '';
}

close FO10;
